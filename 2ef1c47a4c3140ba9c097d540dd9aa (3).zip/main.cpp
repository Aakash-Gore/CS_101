#include <simplecpp>
#include "shooter.h"
#include "bubble.h"

/* Simulation Vars */
const double STEP_TIME = 0.02;
 double time=0;
 int lives=3,score=0;

/* Game Vars */
//const int PLAY_Y_HEIGHT = 450;
const int LEFT_MARGIN = 70;
const int TOP_MARGIN = 20;
const int BOTTOM_MARGIN = (PLAY_Y_HEIGHT+TOP_MARGIN);


void move_bullets(vector<Bullet> &bullets){
    // move all bullets
    for(unsigned int i=0; i<bullets.size(); i++){
        if(!bullets[i].nextStep(STEP_TIME)){
            bullets.erase(bullets.begin()+i);
        }
    }
}

void move_bubbles(vector<Bubble> &bubbles){
    // move all bubbles
    for (unsigned int i=0; i < bubbles.size(); i++)
    {
        bubbles[i].nextStep(STEP_TIME);
    }
}
void bullet_hit_bubble(vector<Bullet> &bullets, vector<Bubble> &bubbles)
{
for(int i=0;i<bullets.size();i++)
{
 for(int j=0; j<bubbles.size();j++)
 {
 if(abs(bullets[i].get_center_x()-bubbles[j].get_center_x())<bubbles[j].get_radius()+bullets[i].get_width()/2 && abs(bullets[i].get_center_y()-bubbles[j].get_center_y())<bubbles[j].get_radius()+bullets[i].get_height()/2)
 {

if(bubbles[j].get_radius()==4*BUBBLE_DEFAULT_RADIUS)
{
 bubbles.push_back(Bubble(bubbles[j].get_center_x(), bubbles[j].get_center_y(), 2*BUBBLE_DEFAULT_RADIUS, -4*BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(255,200,180)));
 bubbles.push_back(Bubble(bubbles[j].get_center_x(), bubbles[j].get_center_y(), 2*BUBBLE_DEFAULT_RADIUS, 4*BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(255,200,180)));
  bullets.erase(bullets.begin()+i);
   bubbles.erase(bubbles.begin()+j);
   score++;
}
 else if(bubbles[j].get_radius()==2*BUBBLE_DEFAULT_RADIUS)
 {
  bubbles.push_back(Bubble(bubbles[j].get_center_x(), bubbles[j].get_center_y(), BUBBLE_DEFAULT_RADIUS, -2*BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(255,105,180)));
   bubbles.push_back(Bubble(bubbles[j].get_center_x(), bubbles[j].get_center_y(), BUBBLE_DEFAULT_RADIUS, 2*BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(255,105,180)));
   bullets.erase(bullets.begin()+i);
   bubbles.erase(bubbles.begin()+j);
   score++;
 }
 else
 {
  bullets.erase(bullets.begin()+i);
  bubbles.erase(bubbles.begin()+j);
  score++;
  }
  //return true;
 }
 }

}
//return false;
}
int bubble_hit_shooter(vector<Bubble> &bubbles, Shooter shooter,char c)
{
 for(int i=0;i<bubbles.size();i++)
 {
  if((abs(bubbles[i].get_center_x()-shooter.get_head_center_x()) < bubbles[i].get_radius()+shooter.get_head_radius() && abs(bubbles[i].get_center_y()-shooter.get_head_center_y()) < bubbles[i].get_radius()+shooter.get_head_radius()) || (abs(bubbles[i].get_center_x()-shooter.get_body_center_x()) < bubbles[i].get_radius()+shooter.get_body_width()/2 && abs(bubbles[i].get_center_y()-shooter.get_body_center_y()) < bubbles[i].get_radius()+shooter.get_body_height()/2))
  {
  lives--;
  //bubbles[i].reverse_dir(c);
 double v1=bubbles[i].get_vx();
  double v2=bubbles[i].get_vy();
  //double x1=bubbles[i].get_center_x();
  Color b=bubbles[i].get_color();
  double r1=bubbles[i].get_radius();
  bubbles.erase(bubbles.begin()+i);
  bubbles.push_back(Bubble(WINDOW_X/2.0, BUBBLE_START_Y, r1, v1,v2 , b));
  Color a=COLOR(200,0,0);

  shooter.change_col(a);
  //shooter.change_col(b);
   return lives;
  }

  //return false;
 }
 return lives;
}
vector<Bubble> create_bubbles()
{
    // create initial bubbles in the game
    vector<Bubble> bubbles;
    bubbles.push_back(Bubble(WINDOW_X/2.0, BUBBLE_START_Y, BUBBLE_DEFAULT_RADIUS, -BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(255,105,180)));
    bubbles.push_back(Bubble(WINDOW_X/4.0, BUBBLE_START_Y, BUBBLE_DEFAULT_RADIUS, BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(255,105,180)));
    return bubbles;
}
vector<Bubble> create_big_bubbles()
{
    // create initial bubbles in the game
    vector<Bubble> bubbles;
    bubbles.push_back(Bubble(WINDOW_X/2.0, BUBBLE_START_Y, 2*BUBBLE_DEFAULT_RADIUS, -2*BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(255,200,180)));
    bubbles.push_back(Bubble(WINDOW_X/4.0, BUBBLE_START_Y, 2*BUBBLE_DEFAULT_RADIUS, 2*BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(255,200,180)));
    return bubbles;
}
vector<Bubble> create_bigger_bubbles()
{
    // create initial bubbles in the game
    vector<Bubble> bubbles;
    bubbles.push_back(Bubble(WINDOW_X/2.0, BUBBLE_START_Y, 4*BUBBLE_DEFAULT_RADIUS, -4*BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(0,200,180)));
    bubbles.push_back(Bubble(WINDOW_X/4.0, BUBBLE_START_Y, 4*BUBBLE_DEFAULT_RADIUS, 4*BUBBLE_DEFAULT_VX, BUBBLE_DEFAULT_VY, COLOR(0,200,180)));
    return bubbles;
}




bool lev1(vector<Bubble> &bubbles,vector<Bullet> &bullets)
{
 XEvent event;
 Shooter shooter(SHOOTER_START_X, SHOOTER_START_Y, SHOOTER_VX);

 string msg_cmd("Cmd: _");
 Text charPressed(LEFT_MARGIN, BOTTOM_MARGIN, msg_cmd);
char c='b';
    // Main game loop
    while (bubbles.size()>0 && bubble_hit_shooter(bubbles,shooter,c)>0 && time<120)
    {

        bool pendingEvent = checkEvent(event);
         Text t1(400,50,floor(time));
         Text t2(400,70,lives);
         Text t3(400,90,score);
         //t1.imprint();
         t2.imprint();
         t3.imprint();
        if (pendingEvent)
        {

            // Get the key pressed
             c = charFromEvent(event);
            msg_cmd[msg_cmd.length() - 1] = c;
            charPressed.setMessage(msg_cmd);

            // Update the shooter
            if(c == 'a')
                shooter.move(STEP_TIME, true);
            else if(c == 'd')
                shooter.move(STEP_TIME, false);
            else if(c == 'w')
                bullets.push_back(shooter.shoot());
            else if(c == 'q')
                break;
        }
        /*if(bullet_hit_bubble(vector<Bullet> &bullets, vector<Bubble> &bubbles))
        {
        bullets.erase(bullets.begin()+i);
        bubbles.erase(buubles.begin()+j);
        }*/
        bullet_hit_bubble(bullets, bubbles);


        // Update the bubbles
        move_bubbles(bubbles);

        // Update the bullets
        move_bullets(bullets);




        wait(STEP_TIME);
        time+=0.06;

    }
    bullets.clear();
    Text t1(400,50,floor(time));
        Text t2(400,70,lives);
         Text t3(400,90,score);



    if(lives>0 && score==2 && time<120)
    {
     Text next_lev(250,250, "LEVEL 2");
     wait(2);
         t1=NULL;
         t2=NULL;
         t3=NULL;
         return true;
         }
         else
         return false;
    }

    bool lev2(vector<Bubble> &bubbles,vector<Bullet> &bullets)
{
 XEvent event;
 time=0;
 Shooter shooter(SHOOTER_START_X, SHOOTER_START_Y, SHOOTER_VX);

 string msg_cmd("Cmd: _");
 Text charPressed(LEFT_MARGIN, BOTTOM_MARGIN, msg_cmd);
      char c='b';
    // Main game loop
    while (bubbles.size()>0 && bubble_hit_shooter(bubbles,shooter,c)>0 && time<120)
    {

        bool pendingEvent = checkEvent(event);
         Text t1(400,50,floor(time));
         Text t2(400,70,lives);
         Text t3(400,90,score);
         //t1.imprint();
         t2.imprint();
         t3.imprint();
        if (pendingEvent)
        {

            // Get the key pressed
             c = charFromEvent(event);
            msg_cmd[msg_cmd.length() - 1] = c;
            charPressed.setMessage(msg_cmd);

            // Update the shooter
            if(c == 'a')
                shooter.move(STEP_TIME, true);
            else if(c == 'd')
                shooter.move(STEP_TIME, false);
            else if(c == 'w')
                bullets.push_back(shooter.shoot());
            else if(c == 'q')
                break;
        }
        /*if(bullet_hit_bubble(vector<Bullet> &bullets, vector<Bubble> &bubbles))
        {
        bullets.erase(bullets.begin()+i);
        bubbles.erase(buubles.begin()+j);
        }*/
        bullet_hit_bubble(bullets, bubbles);


        // Update the bubbles
        move_bubbles(bubbles);

        // Update the bullets
        move_bullets(bullets);




        wait(STEP_TIME);
        time+=0.06;
    }
    bullets.clear();
    //Text lev2(250,250,"LEVEL 2");
    Text t1(400,50,floor(time));
        Text t2(400,70,lives);
         Text t3(400,90,score);

         if(lives>0 && score==8 && time<120)
    {Text next_lev(250,250, "LEVEL 3");
    wait(2);
    t1=NULL;
         t2=NULL;
         t3=NULL;
         return true;
         }
         else
         return false;


}


bool lev3(vector<Bubble> &bubbles,vector<Bullet> &bullets)
{
 XEvent event;
 time=0;
 Shooter shooter(SHOOTER_START_X, SHOOTER_START_Y, SHOOTER_VX);

 string msg_cmd("Cmd: _");
 Text charPressed(LEFT_MARGIN, BOTTOM_MARGIN, msg_cmd);
char  c='b';
    // Main game loop
    while (bubbles.size()>0 && bubble_hit_shooter(bubbles,shooter,c)>0 && time<120)
    {

        bool pendingEvent = checkEvent(event);
         Text t1(400,50,floor(time));
         Text t2(400,70,lives);
         Text t3(400,90,score);
        // t1.imprint();
         t2.imprint();
         t3.imprint();
        if (pendingEvent)
        {

            // Get the key pressed
            c = charFromEvent(event);
            msg_cmd[msg_cmd.length() - 1] = c;
            charPressed.setMessage(msg_cmd);

            // Update the shooter
            if(c == 'a')
                shooter.move(STEP_TIME, true);
            else if(c == 'd')
                shooter.move(STEP_TIME, false);
            else if(c == 'w')
                bullets.push_back(shooter.shoot());
            else if(c == 'q')
                break;
        }
        /*if(bullet_hit_bubble(vector<Bullet> &bullets, vector<Bubble> &bubbles))
        {
        bullets.erase(bullets.begin()+i);
        bubbles.erase(buubles.begin()+j);
        }*/
        bullet_hit_bubble(bullets, bubbles);


        // Update the bubbles
        move_bubbles(bubbles);

        // Update the bullets
        move_bullets(bullets);




        wait(STEP_TIME);
        time+=0.06;
    }
    bullets.clear();
    //Text lev2(250,250,"LEVEL 2");
    Text t1(400,50,floor(time));
        Text t2(400,70,lives);
         Text t3(400,90,score);

         if(lives>0 && score==22 && time<120)
        {


         return true;
         }
         else
         return false;

}


int main()
{
    initCanvas("Bubble Trouble", WINDOW_X, WINDOW_Y);

    Line b1(0, PLAY_Y_HEIGHT, WINDOW_X, PLAY_Y_HEIGHT);
    b1.setColor(COLOR(0, 0, 255));


    Text tim1(370,50,"Time:");Text tim2(427,50,"/120");
    Text liv(370,70,"Health:");
    Text scor(370,90,"Score:");


    // Intialize the shooter
    //shooter is the Shooter object

    // Initialize the bubbles

    getClick();
  vector<Bubble> bubbles = create_bubbles();


    // Initialize the bullets (empty)
    vector<Bullet> bullets;

    XEvent event;

    // Main game loop

    //Text lev2(250,250,"LEVEL 2");
    //Text t1(400,50,floor(time));
       // Text t2(400,70,lives);
        //
       if(!lev1(bubbles,bullets))
        {
         Text t1(400,50,floor(time));
        Text t2(400,70,lives);
         Text t3(400,90,score);
    Text t(250,250,"GAME OVER");
    getClick();
    return 0;
    }
    //wait(2);
    vector<Bubble> big_bubbles=create_big_bubbles();




    bool b=lev2(big_bubbles,bullets);
//Text t3(400,90,score);
        if(!b)
        {
         Text t1(400,50,floor(time));
        Text t2(400,70,lives);
         Text t3(400,90,score);
    Text t(250,250,"GAME OVER");
    getClick();
    return 0;
    }
    vector<Bubble> bigger_bubbles=create_bigger_bubbles();
    bool c=lev3(bigger_bubbles,bullets);
if(!c)
 {
  Text t1(400,50,floor(time));
        Text t2(400,70,lives);
         Text t3(400,90,score);
         //t1.imprint();
         //t2.imprint();
         //t3.imprint();
    Text t(250,250,"GAME OVER");
    getClick();
    return 0;
    }
    else
    {
    Text t1(400,50,floor(time));
        Text t2(400,70,lives);
         Text t3(400,90,score);
    Text t(250,250,"YOU WIN!");
    getClick();
    return 0;
    }








}
