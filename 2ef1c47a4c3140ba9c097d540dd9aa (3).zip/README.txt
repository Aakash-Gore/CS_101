Extra Features added:
1)	Score, Health and Timer added
2)	Bigger bubbles created, which when destroyed, disintegrate into smaller ones(half their radius)
3)	3 levels introduced, with different sized bubbles with different speeds.

Video File link: https://drive.google.com/file/d/1WoMYwZKnptOp0oj8tJbD8Sm_f_S-JDHF/view?usp=sharing